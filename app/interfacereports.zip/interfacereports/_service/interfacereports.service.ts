import { Injectable } from '@angular/core';
import { IInterfaceReport, InterfaceInfo, Idate, InterfaceSummary, InterfaceDetailed } from '../_model/interfacereports.model';
import { Observable } from 'rxjs';
import { LoadApiUrls } from '../../../_helpers/api.urls';
import { ConsumerService } from '../../../_helpers/ConsumerService';

@Injectable({ providedIn: 'root' })

export class InterfaceReportsService {
  component = "Reports";
  interfaceSummaryList: InterfaceSummary[] = [
    { Date: '13-08-2019 03:21:00', Delivered: 2, Failed: 2, interfaceName: "interface!", Submitted: 4, Totalsms: 8, unDelivered: 1, Expired: 1, Rejected: 5 },
    { Date: '18-08-2019 03:21:00', Delivered: 1, Failed: 1, interfaceName: "interface!", Submitted: 1, Totalsms: 3, unDelivered: 5, Expired: 2, Rejected: 2 },
    { Date: '21-08-2019 03:21:00', Delivered: 2, Failed: 3, interfaceName: "interface!", Submitted: 2, Totalsms: 7, unDelivered: 7, Expired: 5, Rejected: 1 },
    { Date: '16-08-2019 03:21:00', Delivered: 3, Failed: 1, interfaceName: "interface!", Submitted: 2, Totalsms: 6, unDelivered: 4, Expired: 7, Rejected: 5 },
  ];
  interfacedetailedList: InterfaceDetailed[] = [{
    mobilenumber: 99949990779, senderId: "Malabar", messageText: "hello", deliveryStatus: "DELIVRD",
    deliveryTime: "2019-04-12 10:06:01", recievedTime: "2019-04-12 10:06:01", submittedTime: "2019-04-12 10:06:01", messageId: "DWESVF111"
  },
  {
    mobilenumber: 99949990778, senderId: "Ajmal", messageText: "hello123", deliveryStatus: "Delivered",
    deliveryTime: "2019-04-12 10:06:01", recievedTime: "2019-04-12 10:06:01", submittedTime: "2019-04-12 10:06:01", messageId: "DWESVF233232"
  },
  {
    mobilenumber: 99949990777, senderId: "Malabar1", messageText: "hello456", deliveryStatus: "DELIVRD",
    deliveryTime: "2019-04-12 10:06:01", recievedTime: "2019-04-12 10:06:01", submittedTime: "2019-04-12 10:06:01", messageId: "DWESVF"
  },
  {
    mobilenumber: 99949990776, senderId: "Malabar2", messageText: "test messgae", deliveryStatus: "DELIVRD",
    deliveryTime: "2019-04-12 10:06:01", recievedTime: "2019-04-12 10:06:01", submittedTime: "2019-04-12 10:06:01", messageId: "DWESVF5665"
  },
  {
    mobilenumber: 99949990775, senderId: "SharafDg", messageText: "hello6", deliveryStatus: "Delivered",
    deliveryTime: "2019-04-12 10:06:01", recievedTime: "2019-04-12 10:06:01", submittedTime: "2019-04-12 10:06:01", messageId: "DWESVF34343"
  },
  {
    mobilenumber: 99949990773, senderId: "SharafDg1", messageText: "helloewewew", deliveryStatus: "DELIVRD",
    deliveryTime: "2019-04-12 10:06:01", recievedTime: "2019-04-12 10:06:01", submittedTime: "2019-01-12 10:06:01", messageId: "DWESVF7676"
  }, {
    mobilenumber: 99949990772, senderId: "SharafDg", messageText: "weweeweewew", deliveryStatus: "Delivered",
    deliveryTime: "2019-04-12 10:06:01", recievedTime: "2019-04-12 10:06:01", submittedTime: "2019-02-12 10:06:01", messageId: "DWESVF565"
  },
  {
    mobilenumber: 99949990779, senderId: "Malabar3", messageText: "helfdfdfdfdlo", deliveryStatus: "DELIVRD",
    deliveryTime: "2019-04-12 10:06:01", recievedTime: "2019-04-12 10:06:01", submittedTime: "2019-03-12 10:06:01", messageId: "DWESVF434"
  },
  {
    mobilenumber: 99949990771, senderId: "Malabar4", messageText: "hello", deliveryStatus: "Delivered",
    deliveryTime: "2019-04-12 10:06:01", recievedTime: "2019-04-12 10:06:01", submittedTime: "2019-05-12 10:05:01", messageId: "DWESVF11"
  },
  {
    mobilenumber: 99949990771, senderId: "Malabar5", messageText: "hefdfdfdfdllo", deliveryStatus: "DELIVRD",
    deliveryTime: "2019-04-12 10:06:01", recievedTime: "2019-04-12 10:06:01", submittedTime: "2019-04-2 10:04:01", messageId: "DWESVF22"
  }
  ]
  constructor(private apiUrls: LoadApiUrls, private consumer: ConsumerService) {
  }

  getInterfaceSummary(summaryInput: any) {
    if(summaryInput)
    return this.interfaceSummaryList;
  }
  getInterfaceDetails(detailedInput: any) {
    if(detailedInput)
    return this.interfacedetailedList;
  }
  getInterfaceReports(submitData): Observable<IInterfaceReport[]> {
    let _apiurlsdetials = this.apiUrls.getApiServiceUrlByComponentAndMethod(this.component, "getInterfaceReport");
    console.log("URL Get from config : =====> ", _apiurlsdetials);
    if (_apiurlsdetials) {
      console.log("URL Get from config : ----> ", _apiurlsdetials.url);
      return this.consumer.serviceConsumer<IInterfaceReport[]>(_apiurlsdetials.url, _apiurlsdetials.type, submitData, 'interfaceReports');
    }
    else {
      console.log("URL Get from config : ----> ", "Url not found..");
      return Observable.throw({ error: { messages: "url not found" } });
    }
  }

  getInterfaces(): Observable<InterfaceInfo[]> {
    let _apiurlsdetials = this.apiUrls.getApiServiceUrlByComponentAndMethod(this.component, "getAllInterfaceInfo");
    console.log("URL Get from config : =====> ", _apiurlsdetials);
    if (_apiurlsdetials) {
      console.log("URL Get from config : ----> ", _apiurlsdetials.url);
      return this.consumer.serviceConsumer<InterfaceInfo[]>(_apiurlsdetials.url, _apiurlsdetials.type, null, 'interfaceInfo');
    }
    else {
      console.log("URL Get from config : ----> ", "Url not found..");
      return Observable.throw({ error: { messages: "url not found" } });
    }
  }
  getCurrentDate(): Observable<Idate> {

    let _apiurlsdetials = this.apiUrls.getApiServiceUrlByComponentAndMethod(this.component, "getCurrentDate")
    if (_apiurlsdetials) {
      console.log("URL Get from config : ---->  ", _apiurlsdetials.url);
      return this.consumer.serviceConsumer<Idate>(_apiurlsdetials.url, _apiurlsdetials.type, null, '');
    }
    else {
      console.log("URL Get from config : ---->  ", "Url not found..");
      return Observable.throw({ error: { messages: "url not found" } });
    }
  }
}