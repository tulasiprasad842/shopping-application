import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InterfaceSummaryComponent } from './interface-summary.component';

describe('InterfaceSummaryComponent', () => {
  let component: InterfaceSummaryComponent;
  let fixture: ComponentFixture<InterfaceSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InterfaceSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InterfaceSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
