import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { Angular5Csv } from 'angular5-csv/dist/Angular5-csv';
import { DatePipe } from '@angular/common';
import { IInterfaceReport, InterfaceSummary } from '../_model/interfacereports.model';
import * as XLSX from 'xlsx';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { ArabicTtfValue } from '../../../_helpers/ArabicTtfValue';
import * as _ from "lodash";
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
declare let jsPDF;
@Component({
  selector: 'app-interface-summary',
  templateUrl: './interface-summary.component.html',
  styleUrls: ['./interface-summary.component.scss']
})
export class InterfaceSummaryComponent implements OnInit {
  interfaceReportsList: InterfaceSummary[] = [];
  @Input() summaryData:InterfaceSummary[];
  @Output() DetailedInput=new EventEmitter<any>()
  filterinterfaceReportsList: InterfaceSummary[] = [];
  displayedColumns = ['interfaceName', 'Date', 'Sent','Submitted', 'Totalsms','Rejected','Expired','unDelivered','Delivered', 'Failed'];
  dateFormatFlag: boolean = false;
  dataSource: MatTableDataSource<InterfaceSummary>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  subscription: any;
  loading: boolean = false;
  public listPage = 0;
  pageSize = environment.pageSize;
  constructor(private datePipe: DatePipe, private arabicTTF: ArabicTtfValue) { }

  ngOnInit() {
    this.interfaceReportsList = this.summaryData;
    if (this.filterinterfaceReportsList.length == this.dataSource.data.length) {
      this.loading = false;
      setTimeout(() => { this.dataSource.sort = this.sort, this.dataSource.paginator = this.paginator });
    } else {
      this.subscription = Observable.interval(1000).subscribe(data => {
        if (this.filterinterfaceReportsList.length == this.dataSource.data.length) {
          if (this.subscription)
            this.subscription.unsubscribe();
          setTimeout(() => { this.dataSource.sort = this.sort, this.dataSource.paginator = this.paginator });
          this.loading = false;
        }
      });
    }
    this.dataSource = new MatTableDataSource<InterfaceSummary>(this.interfaceReportsList);
    console.log("dataSource=>", this.dataSource);
    this.getListData({ pageIndex: this.listPage, pageSize: this.pageSize });
  }
  detailedInterface(interfaceObj:InterfaceSummary,sectionName:string){
    console.log("interfaceObj==>",interfaceObj);
    this.DetailedInput.emit({interfaceName:interfaceObj.interfaceName,sectionName:sectionName});
  }
  ExportTOExcel() {
    if (!this.dateFormatFlag) {
      this.dateFormatFlag = true;
      this.summaryData.forEach(n => {
        n.Date = n.Date == null ? '' : this.datePipe.transform(new Date((n.Date).replace(/\s/g, "T")), "yyyy-MM-dd");
        return n;
      });
    }
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.summaryData.map(data => _.pick(data, this.displayedColumns)));
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    let tdy = new Date();
    let dateDownload = (this.datePipe.transform(tdy, "yyyy MM dd h mm ss")).replace(/\s/g, "");
    XLSX.writeFile(wb, 'Interface_Summary_Reports_' + dateDownload + '.xlsx');
  }

  ExportTOPdf() {
    let doc = new jsPDF('l', 'pt');
 
    let getColumnHeaders = [this.displayedColumns];
    let groupedDataRows = [];
    let temp = [];
    if (!this.dateFormatFlag) {
      this.dateFormatFlag = true;
      this.summaryData.forEach(n => {
        n.Date = n.Date == null ? '' : this.datePipe.transform(new Date((n.Date).replace(/\s/g, "T")), "yyyy-MM-dd");
        return n;
      });
    }
    this.summaryData.forEach(element => {
      temp = [];
      getColumnHeaders[0].forEach(y => {
        temp.push(element[y + ''])
      });
      console.log('temp==>', temp);
      groupedDataRows.push(temp);
      console.log(getColumnHeaders, groupedDataRows);
    });
    console.log("Interface reports groupedDataRows==>", groupedDataRows);
    const isIEOrEdge = /msie\s|trident\//i.test(window.navigator.userAgent);
    if (!isIEOrEdge) {
      doc.addFileToVFS('Amiri-Regular.ttf', this.arabicTTF.arbicTtfString);
      doc.addFont('Amiri-Regular.ttf', 'arabicfont', 'normal');
      doc.addFont('Amiri-Regular.ttf', 'arabicfont', 'bold');
      doc.setFont('arabicfont');
    }
    doc.autoTable({
      head: getColumnHeaders,
      body: groupedDataRows,
      startY: false, tableWidth: 'auto', cellWidth: 'wrap',
      tableLineColor: 200, tableLineWidth: 0,
      columnStyles: {
        0: { cellWidth: 'auto' }, 1: { cellWidth: 'auto' }, 2: { cellWidth: 'auto' }, 3:
          { cellWidth: 'auto' }, 4: { cellWidth: 'auto' },
        5: { cellWidth: 'auto' }, 6: { cellWidth: 'auto' }, 7: { cellWidth: 'auto' }, 8:
          { cellWidth: 'auto' }, 9: { cellWidth: 'auto' }, 10: { cellWidth: 'auto' }, 11: { cellWidth: 'auto' }, 12: { cellWidth: 'auto' }
      },
      headStyles: { theme: 'grid' },
      styles: {
        overflow: 'linebreak', cellWidth: 'wrap', font: "arabicfont",
        fontSize: 10,
        cellPadding: 8, overflowColumns: 'linebreak'
      },
    });
    let tdy = new Date();
    let dateDownload = (this.datePipe.transform(tdy, "yyyy MM dd h mm ss")).replace(/\s/g, "");
    doc.save('Interface_Reports' + dateDownload + '.pdf');
  }
  sortData() {
    this.dataSource.sort = this.sort
  }
  convertData(value) {
    return value == null ? '' : new Date((value).replace(/\s/g, "T"));
  }
  ExportTOCsv() {
    if (!this.dateFormatFlag) {
      this.dateFormatFlag = true;
      this.summaryData.forEach(n => {
        n.Date = n.Date == null ? '' : this.datePipe.transform(new Date((n.Date).replace(/\s/g, "T")), "yyyy-MM-dd");
        return n;
      });  
    }
    console.log("interfaceReportsList==>", JSON.stringify(this.summaryData));
    var options = {
      noDownload: false,
      headers: this.displayedColumns,
    };
    let tdy = new Date();
    let dateDownload = (this.datePipe.transform(tdy, "yyyy MM dd h mm ss")).replace(/\s/g, "");
    new Angular5Csv(this.summaryData.map(data => _.pick(data, this.displayedColumns)), 'Interface_Reports_' + dateDownload, options);
  }

  getListData(_pageData) {
    this.dataSource.paginator = this.paginator;
  }
}
