import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InterfacedetailedReportComponent } from './interfacedetailed-report.component';

describe('InterfacedetailedReportComponent', () => {
  let component: InterfacedetailedReportComponent;
  let fixture: ComponentFixture<InterfacedetailedReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InterfacedetailedReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InterfacedetailedReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
