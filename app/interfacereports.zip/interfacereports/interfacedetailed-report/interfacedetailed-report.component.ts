import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { InterfaceDetailed } from '../_model/interfacereports.model';
import { FormControl } from '@angular/forms';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-interfacedetailed-report',
  templateUrl: './interfacedetailed-report.component.html',
  styleUrls: ['./interfacedetailed-report.component.scss']
})
export class InterfacedetailedReportComponent implements OnInit {
  @Input() DetailedData:InterfaceDetailed[];
  subscription: any;
  interfaceDetailedList:InterfaceDetailed[]=[];
  totaldetailedInterfaces:InterfaceDetailed[]=[];
  public searchCtrl: FormControl = new FormControl();
  displayedColumns=["mobilenumber","senderId", "messageText", "deliveryStatus","deliveryTime","submittedTime","recievedTime","messageId"]
  dataSource = new MatTableDataSource<InterfaceDetailed>(this.totaldetailedInterfaces);
  loading: boolean=false;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  listPage = 0;
  searchdata: string;
  public pageSize = environment.pageSize;
  constructor() { }

  ngOnInit() {
    this.searchCtrl.valueChanges
      .subscribe(
        name => {
          console.log('searchCtrl', name);
          this.dataSource.filter = name;
        });
    this.interfaceDetailedList = this.DetailedData;
    if (this.totaldetailedInterfaces.length == this.dataSource.data.length) {
      this.loading = false;
      setTimeout(() => { this.dataSource.sort = this.sort, this.dataSource.paginator = this.paginator });
    } else {
      this.subscription = Observable.interval(1000).subscribe(data => {
        if (this.totaldetailedInterfaces.length == this.dataSource.data.length) {
          if (this.subscription)
            this.subscription.unsubscribe();
          setTimeout(() => { this.dataSource.sort = this.sort, this.dataSource.paginator = this.paginator });
          this.loading = false;
        }
      });
    }
    this.dataSource = new MatTableDataSource<any>(this.interfaceDetailedList);
    console.log("dataSource=>", this.dataSource);
    this.dataSource.filterPredicate = this.createFilter();
    this.getListData({ pageIndex: this.listPage, pageSize: this.pageSize });
  }
createFilter(): (data: InterfaceDetailed, filter: string) => boolean {
    console.log('createFilter');
    let filterFunction = function (data: InterfaceDetailed, filter): boolean {
      console.log("data=>", data);
      return (data.mobilenumber + '').toLowerCase().indexOf(filter.toLowerCase()) !== -1
        || data.senderId.toLowerCase().indexOf(filter.toLowerCase()) !== -1
        || data.messageText.toLowerCase().indexOf(filter.toLowerCase()) !== -1 ||
        data.deliveryStatus.toLowerCase().indexOf(filter.toLowerCase()) !== -1 ||
        data.deliveryTime.toLowerCase().indexOf(filter.toLowerCase()) !== -1 ||
        data.submittedTime.toLowerCase().indexOf(filter.toLowerCase()) !== -1 ||
        data.recievedTime.toLowerCase().indexOf(filter.toLowerCase()) !== -1
    }
    return filterFunction;
  }
  ngOnDestroy() {
    if (this.subscription)
      this.subscription.unsubscribe();
  }
  getListData(obj) {
    this.dataSource.paginator = this.paginator;
  }

}
