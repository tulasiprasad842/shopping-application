import { InterfacereportsComponent } from './manage/interfacereports.component';
import { Routes } from '@angular/router';

export const InterfaceReportRoutes: Routes = [
    {
        path: '',
        component: InterfacereportsComponent
    }
]
